# PocketMine-NBT
[![Build Status](https://travis-ci.org/pmmp/NBT.svg?branch=master)](https://travis-ci.org/pmmp/NBT)

PHP library for working with the NBT (Named Binary Tag) data storage format, as designed by Mojang.
