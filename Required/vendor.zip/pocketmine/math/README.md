# Math
PHP library containing math related code used in PocketMine-MP
