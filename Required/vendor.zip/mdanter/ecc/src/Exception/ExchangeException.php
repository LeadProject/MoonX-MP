<?php
declare(strict_types=1);

namespace Mdanter\Ecc\Exception;

class ExchangeException extends \RuntimeException
{

}
