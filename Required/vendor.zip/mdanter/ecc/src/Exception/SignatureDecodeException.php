<?php

declare(strict_types=1);

namespace Mdanter\Ecc\Exception;

class SignatureDecodeException extends \RuntimeException
{

}
