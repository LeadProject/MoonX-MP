<?php declare(strict_types = 1);

namespace DaveRandom\CallbackValidator\Test\Fixtures;

class ClassImplementingInvoke
{
    public function __invoke() {}
}
