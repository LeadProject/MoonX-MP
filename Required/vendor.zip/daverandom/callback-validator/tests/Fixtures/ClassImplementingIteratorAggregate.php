<?php declare(strict_types = 1);

namespace DaveRandom\CallbackValidator\Test\Fixtures;

abstract class ClassImplementingIteratorAggregate implements \IteratorAggregate {}
